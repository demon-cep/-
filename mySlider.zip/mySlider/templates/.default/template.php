<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
if (is_array($arResult['SLIDE'])) {
?>
<div  id="featured">
			<?
				foreach ($arResult['SLIDE'] as $slide) {
					if ($slide['DETAIL_PICTURE']['src']) {
					?>
						<img src="<?=$slide['PREVIEW_PICTURE']['src']?>"  alt="<?=$slide['NAME']?>" />
					<?
				}elseif($slide['PREVIEW_PICTURE']['src']){
					?>
						<img src="<?=$slide['PREVIEW_PICTURE']['src']?>"  alt="<?=$slide['NAME']?>" />
					<? 
				}
				}
			?>
		</div> 
<?
}else{
echo GetMessage("NO_ELEMENT");
}
?>
		


