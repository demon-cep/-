<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

class CDemoSqr extends CBitrixComponent
{
     function executeComponent()
    {
    	// проверка на ошибки param
    	if(is_array($this->error($this->arParams))){
        		foreach ($this->error($this->arParams) as $value) {
        			echo $value;
        		}
        		return false;
        	}

        	// кеш и отдаю в template
        if($this->startResultCache())
        {
        	$this->arResult=$this->create_arResult($this->arParams);
            $this->includeComponentTemplate();
        }
        return $this->arResult;
    }
// ошибки
    function error($arParams){
    	$err;
    	if (!$arParams['HEIGHT']) {
    		$err[]=GetMessage("NO_HEIGHT");
    	}
    	if (!$arParams['WIDTH']) {
    		$err[]=GetMessage("NO_WIDTH");
    	}
    	return $err;
    }
    // сборка result
	function create_arResult($arParams){
		CModule::IncludeModule("iblock");

		$arResult["SLIDE"] = array();
		$arFilter=array('IBLOCK_ID'=>$arParams['IBLOCK_ID'],'CHECK_DATES'=>$arParams['CHECK_DATES'],);
		$page_nav=array('nPageSize'=>$arParams['COUNT_ELEMENT']);
		$rsElement = CIBlockElement::GetList(array(), $arFilter,false,$page_nav);
		while($obElement = $rsElement->GetNextElement())
		{
			 $slide= $obElement->GetFields();
			 // ИЗО
			 $slide['PREVIEW_PICTURE']=$this->img_resize($slide['PREVIEW_PICTURE'],$arParams['HEIGHT'],$arParams['WIDTH']);
			 $slide['DETAIL_PICTURE']=$this->img_resize($slide['DETAIL_PICTURE'],$arParams['HEIGHT'],$arParams['WIDTH']);
			 $arResult["SLIDE"][]=$slide;
		}
		return $arResult;
	}
// получинее src и изменение размеров img
	function img_resize($img,$height,$width){
		$pic['ID']=$img;
		$pic = CFile::ResizeImageGet(CFile::GetFileArray($img), array('width'=>$width, 'height'=>$height), BX_RESIZE_IMAGE_EXACT , true);
		return $pic;
	}

}